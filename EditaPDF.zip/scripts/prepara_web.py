"""Prepara la pagina di EditaPDF per l'app o per il sito.

Uso:  python scripts/prepara_web.py CARTELLA_DI_DESTINAZIONE

Copia web/index.html e scarica in lib/ le librerie (PDF, ZIP) e i caratteri,
cosi' l'app funziona anche senza internet.
Copyright (c) Ignazio Paolicelli
"""
import html
import os
import re
import shutil
import sys
import urllib.request

OUT = sys.argv[1]
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB = os.path.join(OUT, "lib")
FONTS = os.path.join(LIB, "fonts")
os.makedirs(FONTS, exist_ok=True)

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=90) as r:
        return r.read()


page = os.path.join(ROOT, "web", "index.html")
shutil.copy(page, os.path.join(OUT, "index.html"))
print("Copiato index.html")

LIBRERIE = [
    "pdf.js/3.11.174/pdf.min.js",
    "pdf.js/3.11.174/pdf.worker.min.js",
    "jspdf/2.5.1/jspdf.umd.min.js",
    "jszip/3.10.1/jszip.min.js",
]
for lib in LIBRERIE:
    data = get("https://cdnjs.cloudflare.com/ajax/libs/" + lib)
    with open(os.path.join(LIB, os.path.basename(lib)), "wb") as f:
        f.write(data)
    print("Scaricata", lib, len(data), "byte")

# Caratteri (solo alfabeto latino) per l'uso senza internet
testo = open(page, encoding="utf-8").read()
css_finale = []
n = 0
for href in re.findall(r'href="(https://fonts\.googleapis\.com/css2[^"]+)"', testo):
    href = html.unescape(href)
    try:
        css = get(href).decode("utf-8")
        for sottoinsieme, blocco in re.findall(r"/\*\s*([\w-]+)\s*\*/\s*(@font-face\s*\{[^}]*\})", css):
            if sottoinsieme not in ("latin", "latin-ext"):
                continue
            for url in re.findall(r"url\((https://[^)]+)\)", blocco):
                n += 1
                nome = "f%03d.woff2" % n
                with open(os.path.join(FONTS, nome), "wb") as f:
                    f.write(get(url))
                blocco = blocco.replace(url, "fonts/" + nome)
            css_finale.append(blocco)
        print("Carattere ok:", href.split("family=")[1].split(":")[0].split("&")[0])
    except Exception as e:  # un carattere che manca non blocca la compilazione
        print("ATTENZIONE carattere non scaricato:", href, e)

with open(os.path.join(LIB, "fonts.css"), "w", encoding="utf-8") as f:
    f.write("\n".join(css_finale))
print("Fatto:", n, "file di caratteri")
