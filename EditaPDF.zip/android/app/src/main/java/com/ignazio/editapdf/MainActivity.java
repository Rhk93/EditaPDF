package com.ignazio.editapdf;

/*
 * EditaPDF per Android
 * Copyright © Ignazio Paolicelli
 *
 * L'app mostra la pagina EditaPDF (assets/www/index.html) e aggiunge:
 *  - apertura file dal telefono (anche "Apri con" e "Condividi")
 *  - salvataggio dei file esportati dove vuoi tu
 *  - download dai link cloud (Mega, Google Drive, Dropbox...) senza blocchi
 */

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final int REQ_APRI = 11;
    private static final int REQ_SALVA = 12;
    private static final String HOST = "appassets.androidplatform.net";

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private ByteArrayOutputStream bufferSalvataggio;
    private Intent intentInAttesa;
    private boolean paginaPronta = false;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService lavori = Executors.newCachedThreadPool();

    private File cartellaCondivisa() {
        File d = new File(getCacheDir(), "shared");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static boolean idValido(String id) {
        return id != null && id.matches("[A-Za-z0-9_]+");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#1D2027"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/shared/", path -> {
                    if (!idValido(path)) return null;
                    File f = new File(cartellaCondivisa(), path);
                    if (!f.exists()) return null;
                    try {
                        return new WebResourceResponse("application/octet-stream", null, new FileInputStream(f));
                    } catch (IOException e) {
                        return null;
                    }
                })
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                paginaPronta = true;
                if (intentInAttesa != null) {
                    Intent i = intentInAttesa;
                    intentInAttesa = null;
                    gestisciIntent(i);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                boolean soloImmagini = true;
                String[] tipi = params.getAcceptTypes();
                if (tipi != null) {
                    for (String t : tipi) {
                        if (t != null && t.contains("pdf")) soloImmagini = false;
                    }
                }
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                if (soloImmagini) {
                    i.setType("image/*");
                } else {
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/*"});
                }
                try {
                    startActivityForResult(Intent.createChooser(i, "Scegli un file"), REQ_APRI);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Ponte(), "AndroidBridge");
        intentInAttesa = getIntent();
        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (paginaPronta) gestisciIntent(intent);
        else intentInAttesa = intent;
    }

    /* Apertura di un file arrivato da "Apri con" o "Condividi" */
    private void gestisciIntent(Intent i) {
        if (i == null) return;
        String azione = i.getAction();
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(azione)) {
            u = i.getData();
        } else if (Intent.ACTION_SEND.equals(azione)) {
            Object extra = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (extra instanceof Uri) u = (Uri) extra;
        }
        if (u == null) return;
        i.setAction(null);
        final Uri uri = u;
        final String mime = i.getType() != null ? i.getType() : "";
        lavori.execute(() -> {
            try {
                String nome = nomeFile(uri);
                String id = "o" + System.currentTimeMillis();
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream out = new FileOutputStream(new File(cartellaCondivisa(), id))) {
                    copia(in, out);
                }
                js("Native._openShared(" + q(id) + "," + q(nome) + "," + q(mime) + ")");
            } catch (Exception e) {
                avviso("Impossibile aprire il file");
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_APRI) {
            if (fileCallback != null) {
                Uri[] r = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    r = new Uri[]{data.getData()};
                }
                fileCallback.onReceiveValue(r);
                fileCallback = null;
            }
        } else if (requestCode == REQ_SALVA) {
            final byte[] dati = bufferSalvataggio != null ? bufferSalvataggio.toByteArray() : new byte[0];
            bufferSalvataggio = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                js("Native._saved(false)");
                return;
            }
            final Uri uri = data.getData();
            lavori.execute(() -> {
                try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                    if (o == null) throw new IOException("destinazione non valida");
                    o.write(dati);
                    js("Native._saved(true)");
                } catch (Exception e) {
                    avviso("Errore nel salvataggio");
                    js("Native._saved(false)");
                }
            });
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        web.evaluateJavascript("(window.Native && Native.back()) ? '1' : '0'", v -> {
            if (!"\"1\"".equals(v)) finish();
        });
    }

    /* ---------- Ponte chiamato dalla pagina ---------- */
    public class Ponte {

        @JavascriptInterface
        public void saveStart() {
            bufferSalvataggio = new ByteArrayOutputStream();
        }

        @JavascriptInterface
        public void saveChunk(String b64) {
            if (bufferSalvataggio == null) bufferSalvataggio = new ByteArrayOutputStream();
            byte[] d = Base64.decode(b64, Base64.DEFAULT);
            bufferSalvataggio.write(d, 0, d.length);
        }

        @JavascriptInterface
        public void saveFinish(final String nome, final String mime) {
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                i.putExtra(Intent.EXTRA_TITLE, nome);
                try {
                    startActivityForResult(i, REQ_SALVA);
                } catch (Exception e) {
                    avviso("Non trovo dove salvare il file");
                    js("Native._saved(false)");
                }
            });
        }

        @JavascriptInterface
        public void closeApp() {
            ui.post(() -> finish());
        }

        @JavascriptInterface
        public void release(String id) {
            if (!idValido(id)) return;
            new File(cartellaCondivisa(), id).delete();
        }

        @JavascriptInterface
        public void fetchUrl(final String id, final String url, final String method, final String body, final String contentType) {
            if (!idValido(id)) return;
            lavori.execute(() -> {
                HttpURLConnection c = null;
                String metodo = (method == null || method.isEmpty()) ? "GET" : method;
                try {
                    URL indirizzo = new URL(url);
                    int salti = 0;
                    while (true) {
                        c = (HttpURLConnection) indirizzo.openConnection();
                        c.setInstanceFollowRedirects(false);
                        c.setConnectTimeout(20000);
                        c.setReadTimeout(90000);
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) EditaPDF/1.0");
                        c.setRequestMethod(metodo);
                        if ("POST".equals(metodo)) {
                            c.setDoOutput(true);
                            if (contentType != null && !contentType.isEmpty()) c.setRequestProperty("Content-Type", contentType);
                            try (OutputStream o = c.getOutputStream()) {
                                o.write((body == null ? "" : body).getBytes("UTF-8"));
                            }
                        }
                        int codice = c.getResponseCode();
                        String dove = c.getHeaderField("Location");
                        if (codice >= 300 && codice < 400 && dove != null && salti < 10) {
                            indirizzo = new URL(indirizzo, dove);
                            c.disconnect();
                            salti++;
                            metodo = "GET";
                            continue;
                        }
                        if (codice >= 400) throw new IOException("Il server ha risposto con errore " + codice);
                        break;
                    }
                    String mime = c.getContentType() == null ? "" : c.getContentType();
                    String nome = nomeDaIntestazione(c.getHeaderField("Content-Disposition"));
                    try (InputStream in = c.getInputStream();
                         OutputStream out = new FileOutputStream(new File(cartellaCondivisa(), id))) {
                        copia(in, out);
                    }
                    js("Native._fetched(" + q(id) + ",true,''," + q(mime) + "," + q(nome) + ")");
                } catch (Exception e) {
                    js("Native._fetched(" + q(id) + ",false," + q("Download non riuscito: " + e.getMessage()) + ",'','')");
                } finally {
                    if (c != null) c.disconnect();
                }
            });
        }
    }

    /* ---------- Utilità ---------- */
    private void js(final String codice) {
        ui.post(() -> web.evaluateJavascript(codice, null));
    }

    private void avviso(final String testo) {
        ui.post(() -> Toast.makeText(MainActivity.this, testo, Toast.LENGTH_LONG).show());
    }

    private static String q(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    private static void copia(InputStream in, OutputStream out) throws IOException {
        if (in == null) throw new IOException("file non leggibile");
        byte[] b = new byte[64 * 1024];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }

    private String nomeFile(Uri uri) {
        String nome = "file";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && c.getString(i) != null) nome = c.getString(i);
            }
        } catch (Exception e) {
            String p = uri.getLastPathSegment();
            if (p != null) nome = p;
        }
        return nome;
    }

    private static String nomeDaIntestazione(String cd) {
        if (cd == null) return "";
        Matcher m = Pattern.compile("filename\\*=UTF-8''([^;]+)", Pattern.CASE_INSENSITIVE).matcher(cd);
        if (!m.find()) {
            m = Pattern.compile("filename=\"?([^\";]+)\"?", Pattern.CASE_INSENSITIVE).matcher(cd);
            if (!m.find()) return "";
        }
        try {
            return URLDecoder.decode(m.group(1), "UTF-8");
        } catch (Exception e) {
            return m.group(1);
        }
    }
}
