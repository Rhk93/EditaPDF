// EditaPDF per Mac e Windows - Copyright © Ignazio Paolicelli
const { app, BrowserWindow, ipcMain, dialog, shell, protocol, net } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');

const ROOT = path.join(__dirname, 'app');
protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }
]);

let win = null;
let fileInAttesa = null;
const FILE_OK = /\.(pdf|png|jpe?g|webp|gif|bmp)$/i;

function inviaFile(p) {
  if (!win) { fileInAttesa = p; return; }
  try {
    const data = fs.readFileSync(p);
    win.webContents.send('open-file', { name: path.basename(p), data });
  } catch (e) { /* file non leggibile */ }
}

function creaFinestra() {
  win = new BrowserWindow({
    width: 1300, height: 880, minWidth: 700, minHeight: 500,
    title: 'EditaPDF', backgroundColor: '#1d2027',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.setMenuBarVisibility(false);
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('app://')) { e.preventDefault(); shell.openExternal(url); } });
  win.webContents.on('did-finish-load', () => { if (fileInAttesa) { const p = fileInAttesa; fileInAttesa = null; inviaFile(p); } });
  win.on('closed', () => { win = null; });
  win.loadURL('app://editapdf/index.html');
}

// Mac: file aperto con "Apri con..."
app.on('open-file', (e, p) => { e.preventDefault(); if (win && !win.webContents.isLoading()) inviaFile(p); else fileInAttesa = p; });

// Windows: file passato all'avvio
const arg = process.argv.slice(1).find(a => FILE_OK.test(a));
if (arg) fileInAttesa = arg;

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', (e, argv) => {
    const f = argv.slice(1).find(a => FILE_OK.test(a));
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); if (f) inviaFile(f); }
  });

  app.whenReady().then(() => {
    protocol.handle('app', req => {
      const u = new URL(req.url);
      const full = path.normalize(path.join(ROOT, decodeURIComponent(u.pathname)));
      if (!full.startsWith(ROOT)) return new Response('Vietato', { status: 403 });
      return net.fetch(pathToFileURL(full).toString());
    });
    creaFinestra();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) creaFinestra(); });
  });
}

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// Salvataggio dei file esportati
ipcMain.handle('save-file', async (e, { name, data }) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('documents'), name) });
  if (r.canceled || !r.filePath) return { ok: false };
  fs.writeFileSync(r.filePath, Buffer.from(data));
  return { ok: true, path: r.filePath };
});

// Download dai link cloud (Mega, Google Drive, Dropbox...) senza i blocchi del browser
ipcMain.handle('fetch-url', async (e, { url, method, body, contentType }) => {
  try {
    const headers = { 'User-Agent': 'Mozilla/5.0 EditaPDF/1.0' };
    if (contentType) headers['Content-Type'] = contentType;
    const res = await fetch(url, { method: method || 'GET', body: body || undefined, headers, redirect: 'follow' });
    if (!res.ok) return { error: 'Il server ha risposto con errore ' + res.status };
    const data = Buffer.from(await res.arrayBuffer());
    let name = '';
    const cd = res.headers.get('content-disposition') || '';
    const m = cd.match(/filename\*=UTF-8''([^;]+)/i) || cd.match(/filename="?([^";]+)"?/i);
    if (m) { try { name = decodeURIComponent(m[1]); } catch (x) { name = m[1]; } }
    return { data, type: res.headers.get('content-type') || '', name };
  } catch (err) {
    return { error: 'Download non riuscito: ' + err.message };
  }
});
