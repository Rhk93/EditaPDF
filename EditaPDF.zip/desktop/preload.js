// EditaPDF - ponte tra la pagina e il computer. Copyright © Ignazio Paolicelli
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('desktopAPI', {
  saveFile: (name, data) => ipcRenderer.invoke('save-file', { name, data }),
  fetchUrl: (opts) => ipcRenderer.invoke('fetch-url', opts),
  onOpenFile: (cb) => ipcRenderer.on('open-file', (e, f) => cb(f)),
  onAskClose: (cb) => ipcRenderer.on('ask-close', () => cb()),
  confirmClose: () => ipcRenderer.invoke('confirm-close')
});
