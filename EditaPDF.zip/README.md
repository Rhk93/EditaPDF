# EditaPDF

Modifica PDF e immagini: gomma, selezione e spostamento di aree, testo con qualsiasi carattere, trasparenza, riquadri colorati e diagrammi degli accordi per chitarra sulle partiture.

**Copyright © Ignazio Paolicelli**

## Versioni
| Dove | File (in *Releases*) |
|---|---|
| Android | `EditaPDF-Android.apk` |
| Mac con chip M1/M2/M3/M4 | `EditaPDF-Mac-AppleSilicon.zip` |
| Mac con processore Intel | `EditaPDF-Mac-Intel.zip` |
| Windows | `EditaPDF-Setup.exe` (si installa) o `EditaPDF-Portable.exe` (parte subito) |
| Web | sito GitHub Pages, oppure `EditaPDF-Web.zip` |

GitHub compila tutto da solo a ogni caricamento (scheda **Actions**), poi mette i file in **Releases**.

## Struttura
- `web/index.html` – l'app vera e propria (unico file, usato da tutte le versioni)
- `android/` – app Android
- `desktop/` – app Mac e Windows
- `scripts/prepara_web.py` – prepara la pagina e scarica le librerie per l'uso offline
- `.github/workflows/` – compilazione automatica
